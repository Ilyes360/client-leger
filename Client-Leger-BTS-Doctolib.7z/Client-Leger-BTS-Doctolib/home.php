<div id="home">
	<h2 class="page-title"> Accueil </h2>

	<h1> Bienvenue! </h1>
	<p>
		Utilisateur connecté
		<br />
		<?php
			echo $_SESSION['nom'] . " " . $_SESSION['prenom'];
		?>
		
	</p>


	<p>
		Ce site a été réalisé par Mathieu, Ilyes et Baptiste du CFA Insta <br />
		Site créé le 21/11/2023. <br /><br /><br />


		Pas de droits réservés <br /><br />

		Bonne visite
	</p>
</div>